# SECONDARY — AWS parallel; GCP is the primary narrative of this demo.
"""Thin Lambda adapter. Not the Cloud Run process. No outbound HTTP."""

import json


def handler(event, context):
    payload = event or {}
    path = payload.get("rawPath") or "/"
    method = ((payload.get("requestContext") or {}).get("http") or {}).get("method", "GET")
    if path == "/healthz" and method == "GET":
        return _json(200, {"status": "ok", "runtime": "lambda-secondary"})
    if path == "/readyz" and method == "GET":
        return _json(200, {"status": "ready", "runtime": "lambda-secondary"})
    if path == "/metrics" and method == "GET":
        body = "\n".join(
            [
                "# HELP insights_lambda_adapter Secondary adapter process marker.",
                "# TYPE insights_lambda_adapter gauge",
                "insights_lambda_adapter 1",
                "",
            ]
        )
        return {
            "statusCode": 200,
            "headers": {"content-type": "text/plain; version=0.0.4; charset=utf-8"},
            "body": body,
        }
    return _json(404, {"error": "not_found", "method": method, "path": path})


def _json(status, body):
    return {
        "statusCode": status,
        "headers": {"content-type": "application/json"},
        "body": json.dumps(body),
    }
