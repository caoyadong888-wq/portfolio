# AWS parallel (secondary)

**SECONDARY — AWS parallel; GCP is the primary narrative of this demo.**

次要. This directory is a thin Lambda + API Gateway HTTP API + CodeBuild + GitHub OIDC fragment for the same fictional insights-api. GCP Cloud Run is the main story. Nothing here is deployed to an AWS account. There is no VPC, no load balancer, and no NAT gateway.

Thistle Analytics is fictional. Account `000000000000` is a placeholder. Configs are real files and are offline-validated. They are not deployed to any cloud account.

## What is here

- `lambda/handler.py` — a small adapter that answers `/healthz`, `/readyz`, and `/metrics`. It is not the Cloud Run process.
- `template.yaml` — SAM: HTTP API to that function, an execution role, and a deploy role that can update only that function.
- `codebuild/buildspec.yml` — install, pre_build, build, post_build.
- `.github/workflows/aws-deploy.yml.fragment` — OIDC via `aws-actions/configure-aws-credentials`, pinned to a full commit SHA.
- `iam/` — the same two roles in a form conftest can read.
- `monitoring/alarms.json` — three CloudWatch alarms: errors, latency, throttles.

`make check` does not call the AWS API.
