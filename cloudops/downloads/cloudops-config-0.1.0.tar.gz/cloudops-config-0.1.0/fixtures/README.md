# Fixtures

`compliant/` must pass `conftest test` against `policies/iam.rego`.

`negative/` must fail that test. Each file is one violation: public `run.admin`, public secret write, `roles/editor`, `roles/owner`, or a runtime service account with `roles/iam.serviceAccountUser`.

Emails and project ids are placeholders for the fictional Thistle Analytics demo.
