# Checkov exceptions

HIGH findings listed in the table are accepted. Any other HIGH failure fails `make check`. The scanner is invoked with these ids skipped, and the skip list is compared to this file.

Medium and low findings are fixed in the templates when the change stays inside this demo. This file does not quote a price.

| Check | Severity | Reason |
| --- | --- | --- |
| CKV_AWS_117 | UNKNOWN | Option A is a Lambda function with no VPC. The spec forbids a network module, load balancer, or NAT on this secondary path, so VpcConfig is intentionally absent. |
