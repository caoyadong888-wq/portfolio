package main

import rego.v1

# Offline IAM rules for CloudOps.
# GCP predefined roles are lowercase (roles/owner, roles/editor). The check is
# case-insensitive so both the spec pattern and the real role names fail.

deny contains msg if {
	some binding in object.get(input, "bindings", [])
	member_is_public(binding.member)
	dangerous_role(binding.role)
	msg := sprintf("public principal %v must not receive %v", [binding.member, binding.role])
}

deny contains msg if {
	some binding in object.get(input, "bindings", [])
	regex.match("(?i)(owner|editor)$", binding.role)
	msg := sprintf("role %v matches Owner or Editor", [binding.role])
}

deny contains msg if {
	some binding in object.get(input, "bindings", [])
	binding.purpose == "runtime"
	binding.role == "roles/iam.serviceAccountUser"
	msg := sprintf("runtime SA %v must not have serviceAccountUser", [binding.member])
}

member_is_public(member) if {
	endswith(sprintf("%v", [member]), "allUsers")
}

member_is_public(member) if {
	endswith(sprintf("%v", [member]), "allAuthenticatedUsers")
}

dangerous_role(role) if {
	role == "roles/run.admin"
}

dangerous_role(role) if {
	secret_write(role)
}

secret_write(role) if {
	regex.match("secretmanager\\.", role)
	not role == "roles/secretmanager.secretAccessor"
	not role == "roles/secretmanager.viewer"
}
