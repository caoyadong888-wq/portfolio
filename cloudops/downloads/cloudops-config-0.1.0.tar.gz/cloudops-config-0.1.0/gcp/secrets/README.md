# Secret Manager reference

Resource name: `insights-api-signing-key`.

This directory has no secret value, no version payload, and no JSON key. A real project would create the secret out of band and mount a pinned version.

## Mount

Cloud Run reads the secret. The service YAML uses `valueFrom.secretKeyRef`. The version in this demo is the placeholder `1`. Production should pin an explicit version. `latest` moves when someone adds a version, so a deploy can change bytes without a config diff.

```yaml
env:
  - name: SIGNING_KEY
    valueFrom:
      secretKeyRef:
        name: insights-api-signing-key
        key: "1"
```

Volume form, same secret, still no value in git:

```yaml
volumeMounts:
  - name: signing-key
    mountPath: /run/secrets/insights-api
volumes:
  - name: signing-key
    secret:
      secretName: insights-api-signing-key
      items:
        - key: "1"
          path: signing-key
```

The process would read `/run/secrets/insights-api/signing-key`. That path is a placeholder. Nothing in this repo creates the file.

## Rotation

Add a new secret version in Secret Manager. Change the pinned version in `gcp/run/service.yaml` and in `gcp/terraform`. Deploy that config. Then disable the previous version after the new revision is serving. The runtime service account has `roles/secretmanager.secretAccessor` on this secret only. It cannot add versions.

## IAM

`projects/thistle-analytics-demo/secrets/insights-api-signing-key` is the resource. Accessor: `insights-api-sa@thistle-analytics-demo.iam.gserviceaccount.com`.
