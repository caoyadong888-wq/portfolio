locals {
  runtime_email = "insights-api-sa@${var.project_id}.iam.gserviceaccount.com"
  build_email   = "cloud-build-sa@${var.project_id}.iam.gserviceaccount.com"
  github_email  = "github-deploy-sa@${var.project_id}.iam.gserviceaccount.com"
  caller_email  = "internal-caller@${var.project_id}.iam.gserviceaccount.com"
  image         = "${var.region}-docker.pkg.dev/${var.project_id}/apps/${var.service_name}:${var.image_tag}"
  wif_member    = "principalSet://iam.googleapis.com/projects/${var.project_number}/locations/global/workloadIdentityPools/github-pool/attribute.repository/example.invalid/thistle-analytics/insights-api"
  iam_members = [
    "serviceAccount:${local.runtime_email}",
    "serviceAccount:${local.build_email}",
    "serviceAccount:${local.github_email}",
    "serviceAccount:${local.caller_email}",
    local.wif_member,
  ]
}
