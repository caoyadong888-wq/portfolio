output "service_name" {
  value       = google_cloud_run_v2_service.insights.name
  description = "Cloud Run service name."
}

output "service_location" {
  value       = google_cloud_run_v2_service.insights.location
  description = "Cloud Run region."
}

output "ingress" {
  value       = google_cloud_run_v2_service.insights.ingress
  description = "Ingress mode. Internal only in this demo."
}

output "image" {
  value       = local.image
  description = "Placeholder Artifact Registry image."
}

output "runtime_account_id" {
  value       = google_service_account.runtime.account_id
  description = "Runtime service account id."
}

output "secret_id" {
  value       = google_secret_manager_secret.signing.secret_id
  description = "Secret Manager id. No secret version is created."
}

output "iam_members" {
  value       = local.iam_members
  description = "Members referenced by this module."
}

output "alert_policy_names" {
  value = [
    google_monitoring_alert_policy.run_5xx.display_name,
    google_monitoring_alert_policy.run_p95.display_name,
    google_monitoring_alert_policy.concurrency.display_name,
    google_monitoring_alert_policy.error_logs.display_name,
    google_monitoring_alert_policy.uptime.display_name,
    google_monitoring_alert_policy.wif_auth.display_name,
  ]
  description = "Alert policy display names expressed in Terraform."
}
