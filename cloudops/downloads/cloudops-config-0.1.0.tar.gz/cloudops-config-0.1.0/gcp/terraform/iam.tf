resource "google_secret_manager_secret_iam_member" "runtime_accessor" {
  secret_id = google_secret_manager_secret.signing.secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${local.runtime_email}"
}

resource "google_project_iam_member" "runtime_logs" {
  project = var.project_id
  role    = "roles/logging.logWriter"
  member  = "serviceAccount:${local.runtime_email}"
}

resource "google_project_iam_member" "runtime_trace" {
  project = var.project_id
  role    = "roles/cloudtrace.agent"
  member  = "serviceAccount:${local.runtime_email}"
}

resource "google_cloud_run_v2_service_iam_member" "caller_invoker" {
  project  = var.project_id
  location = google_cloud_run_v2_service.insights.location
  name     = google_cloud_run_v2_service.insights.name
  role     = "roles/run.invoker"
  member   = "serviceAccount:${local.caller_email}"
}

resource "google_cloud_run_v2_service_iam_member" "build_admin" {
  project  = var.project_id
  location = google_cloud_run_v2_service.insights.location
  name     = google_cloud_run_v2_service.insights.name
  role     = "roles/run.admin"
  member   = "serviceAccount:${local.build_email}"
}

resource "google_cloud_run_v2_service_iam_member" "github_admin" {
  project  = var.project_id
  location = google_cloud_run_v2_service.insights.location
  name     = google_cloud_run_v2_service.insights.name
  role     = "roles/run.admin"
  member   = "serviceAccount:${local.github_email}"
}

resource "google_artifact_registry_repository_iam_member" "build_writer" {
  project    = var.project_id
  location   = google_artifact_registry_repository.apps.location
  repository = google_artifact_registry_repository.apps.repository_id
  role       = "roles/artifactregistry.writer"
  member     = "serviceAccount:${local.build_email}"
}

resource "google_artifact_registry_repository_iam_member" "github_writer" {
  project    = var.project_id
  location   = google_artifact_registry_repository.apps.location
  repository = google_artifact_registry_repository.apps.repository_id
  role       = "roles/artifactregistry.writer"
  member     = "serviceAccount:${local.github_email}"
}

resource "google_service_account_iam_member" "build_actas" {
  service_account_id = "projects/${var.project_id}/serviceAccounts/${local.runtime_email}"
  role               = "roles/iam.serviceAccountUser"
  member             = "serviceAccount:${local.build_email}"
}

resource "google_service_account_iam_member" "github_actas" {
  service_account_id = "projects/${var.project_id}/serviceAccounts/${local.runtime_email}"
  role               = "roles/iam.serviceAccountUser"
  member             = "serviceAccount:${local.github_email}"
}

resource "google_service_account_iam_member" "github_wif" {
  service_account_id = "projects/${var.project_id}/serviceAccounts/${local.github_email}"
  role               = "roles/iam.workloadIdentityUser"
  member             = local.wif_member
}
