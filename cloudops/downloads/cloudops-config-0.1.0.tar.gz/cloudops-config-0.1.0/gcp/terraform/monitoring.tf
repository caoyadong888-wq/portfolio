locals {
  channel = "projects/${var.project_id}/notificationChannels/placeholder-channel"
}

resource "google_monitoring_alert_policy" "run_5xx" {
  display_name = "insights-api Cloud Run 5xx ratio"
  combiner     = "OR"
  severity     = "CRITICAL"
  enabled      = true

  documentation {
    content   = "5xx ratio for insights-api. Placeholder notification channel. Not deployed."
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "5xx ratio over 5 percent"
    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"insights-api\" AND metric.type = \"run.googleapis.com/request_count\" AND metric.labels.response_code_class = \"5xx\""
      comparison      = "COMPARISON_GT"
      threshold_value = 0.05
      duration        = "300s"
      aggregations {
        alignment_period   = "60s"
        per_series_aligner = "ALIGN_RATE"
      }
    }
  }

  notification_channels = [local.channel]
}

resource "google_monitoring_alert_policy" "run_p95" {
  display_name = "insights-api Cloud Run p95 latency"
  combiner     = "OR"
  severity     = "WARNING"
  enabled      = true

  documentation {
    content   = "p95 latency for insights-api. Not deployed."
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "p95 latency over 800ms"
    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"insights-api\" AND metric.type = \"run.googleapis.com/request_latencies\""
      comparison      = "COMPARISON_GT"
      threshold_value = 800
      duration        = "300s"
      aggregations {
        alignment_period   = "60s"
        per_series_aligner = "ALIGN_PERCENTILE_95"
      }
    }
  }

  notification_channels = [local.channel]
}

resource "google_monitoring_alert_policy" "concurrency" {
  display_name = "insights-api instance and concurrency anomaly"
  combiner     = "OR"
  severity     = "WARNING"
  enabled      = true

  documentation {
    content   = "Instance count near maxScale. Not deployed."
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "instance count at maxScale"
    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND resource.labels.service_name = \"insights-api\" AND metric.type = \"run.googleapis.com/container/instance_count\""
      comparison      = "COMPARISON_GT"
      threshold_value = 9
      duration        = "300s"
      aggregations {
        alignment_period   = "60s"
        per_series_aligner = "ALIGN_MAX"
      }
    }
  }

  notification_channels = [local.channel]
}

resource "google_monitoring_alert_policy" "error_logs" {
  display_name = "insights-api application error log spike"
  combiner     = "OR"
  severity     = "ERROR"
  enabled      = true

  documentation {
    content   = "Log-based metric insights_api_app_errors. Not deployed."
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "error log lines"
    condition_threshold {
      filter          = "resource.type = \"cloud_run_revision\" AND metric.type = \"logging.googleapis.com/user/insights_api_app_errors\""
      comparison      = "COMPARISON_GT"
      threshold_value = 20
      duration        = "300s"
      aggregations {
        alignment_period   = "60s"
        per_series_aligner = "ALIGN_DELTA"
      }
    }
  }

  notification_channels = [local.channel]
}

resource "google_monitoring_alert_policy" "uptime" {
  display_name = "insights-api uptime check failed"
  combiner     = "OR"
  severity     = "CRITICAL"
  enabled      = true

  documentation {
    content   = "Uptime host insights-api.thistle.example. The portfolio build does not probe it."
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "uptime check passed is below 1"
    condition_threshold {
      filter          = "resource.type = \"uptime_url\" AND metric.type = \"monitoring.googleapis.com/uptime_check/check_passed\" AND resource.labels.host = \"insights-api.thistle.example\""
      comparison      = "COMPARISON_LT"
      threshold_value = 1
      duration        = "300s"
      aggregations {
        alignment_period   = "60s"
        per_series_aligner = "ALIGN_NEXT_OLDER"
      }
    }
  }

  notification_channels = [local.channel]
}

resource "google_monitoring_alert_policy" "wif_auth" {
  display_name = "insights-api WIF or deploy SA auth failure"
  combiner     = "OR"
  severity     = "ERROR"
  enabled      = true

  documentation {
    content   = "Deploy service account or Workload Identity pool authentication errors. Not deployed."
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "WIF or deploy authentication error"
    condition_matched_log {
      filter = "severity>=ERROR AND protoPayload.authenticationInfo.principalEmail=\"github-deploy-sa@thistle-analytics-demo.iam.gserviceaccount.com\""
    }
  }

  notification_channels = [local.channel]
}
