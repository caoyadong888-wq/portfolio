# Terraform expression of the GCP path

This module is the same intent as the YAML under `gcp/`: Cloud Run service `insights-api`, a dedicated runtime service account, Secret Manager reference with no secret version, Artifact Registry, Workload Identity Federation, scoped IAM, and six alert policies.

`make check` runs `terraform fmt`, `terraform init -backend=false`, `terraform validate`, and `terraform test` with `mock_provider`. It does not run `terraform plan` against a real project and it does not run `terraform apply`.

The Google provider is pinned to 6.50.0. The project id `thistle-analytics-demo` and project number `000000000000` are placeholders. Thistle Analytics is fictional. This module is not deployed to any cloud account.

Monitoring JSON under `gcp/monitoring/policies/` is the schema-checked catalog. The resources in `monitoring.tf` repeat that catalog so a mock plan can assert the six names.
