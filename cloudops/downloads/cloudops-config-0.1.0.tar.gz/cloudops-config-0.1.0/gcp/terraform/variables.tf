variable "project_id" {
  type        = string
  description = "Placeholder GCP project id. Not a project this demo creates."
  default     = "thistle-analytics-demo"
}

variable "project_number" {
  type        = string
  description = "Placeholder project number used only in the Workload Identity principal."
  default     = "000000000000"
}

variable "region" {
  type        = string
  description = "Cloud Run and Artifact Registry region."
  default     = "asia-east1"
}

variable "service_name" {
  type        = string
  description = "Cloud Run service name."
  default     = "insights-api"
}

variable "image_tag" {
  type        = string
  description = "Placeholder image tag. Production should pin a digest."
  default     = "0.1.0"
}

variable "kms_key_id" {
  type        = string
  description = "Placeholder CMEK resource name. This module does not create key material."
  default     = "projects/thistle-analytics-demo/locations/asia-east1/keyRings/insights/cryptoKeys/app"
}

variable "max_instance_count" {
  type        = number
  description = "Upper bound for Cloud Run instances."
  default     = 10
}

variable "max_instance_request_concurrency" {
  type        = number
  description = "Concurrent requests per instance."
  default     = 80
}
