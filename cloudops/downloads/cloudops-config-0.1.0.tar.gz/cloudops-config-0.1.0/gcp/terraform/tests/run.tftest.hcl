mock_provider "google" {}

run "private_service_and_least_privilege" {
  command = plan

  assert {
    condition     = output.service_name == "insights-api"
    error_message = "Cloud Run service must be named insights-api"
  }

  assert {
    condition     = output.service_location == "asia-east1"
    error_message = "region must be asia-east1"
  }

  assert {
    condition     = output.ingress == "INGRESS_TRAFFIC_INTERNAL_ONLY"
    error_message = "ingress must stay internal"
  }

  assert {
    condition     = output.runtime_account_id == "insights-api-sa"
    error_message = "runtime service account must be dedicated"
  }

  assert {
    condition     = output.secret_id == "insights-api-signing-key"
    error_message = "secret id must be the documented placeholder"
  }

  assert {
    condition     = length(output.alert_policy_names) == 6
    error_message = "terraform should express six alert policies"
  }

  assert {
    condition = alltrue([
      for member in output.iam_members :
      !strcontains(member, "allUsers") && !strcontains(member, "allAuthenticatedUsers")
    ])
    error_message = "no public member may appear in the IAM set"
  }

  assert {
    condition     = google_cloud_run_v2_service.insights.template[0].max_instance_request_concurrency == 80
    error_message = "concurrency must be set"
  }

  assert {
    condition     = google_cloud_run_v2_service.insights.template[0].scaling[0].max_instance_count == 10
    error_message = "maxScale must be bounded"
  }
}
