resource "google_service_account" "runtime" {
  account_id   = "insights-api-sa"
  display_name = "insights-api runtime"
  description  = "Dedicated runtime identity. Not the default compute service account."
}

resource "google_service_account" "build" {
  account_id   = "cloud-build-sa"
  display_name = "Cloud Build deploy"
  description  = "Deploy identity for Cloud Build. Scoped in iam.tf."
}

resource "google_service_account" "github" {
  account_id   = "github-deploy-sa"
  display_name = "GitHub Actions deploy"
  description  = "Deploy identity for Workload Identity Federation."
}

resource "google_service_account" "caller" {
  account_id   = "internal-caller"
  display_name = "Internal Cloud Run invoker"
  description  = "Placeholder caller. Public invoker is not granted."
}

resource "google_artifact_registry_repository" "apps" {
  location      = var.region
  repository_id = "apps"
  format        = "DOCKER"
  description   = "Images for the fictional Thistle Analytics insights-api. Not deployed by this demo."
  kms_key_name  = var.kms_key_id

  depends_on = [google_service_account.runtime]
}

resource "google_secret_manager_secret" "signing" {
  secret_id = "insights-api-signing-key"

  replication {
    user_managed {
      replicas {
        location = var.region
        customer_managed_encryption {
          kms_key_name = var.kms_key_id
        }
      }
    }
  }

  depends_on = [google_service_account.runtime]
}

resource "google_cloud_run_v2_service" "insights" {
  name     = var.service_name
  location = var.region
  ingress  = "INGRESS_TRAFFIC_INTERNAL_ONLY"

  template {
    service_account                  = local.runtime_email
    max_instance_request_concurrency = var.max_instance_request_concurrency
    timeout                          = "60s"
    execution_environment            = "EXECUTION_ENVIRONMENT_GEN2"

    scaling {
      min_instance_count = 0
      max_instance_count = var.max_instance_count
    }

    containers {
      image = local.image

      ports {
        name           = "http1"
        container_port = 8080
      }

      resources {
        limits = {
          cpu    = "1"
          memory = "512Mi"
        }
      }

      env {
        name  = "INSIGHTS_ENV"
        value = "demo"
      }

      env {
        name = "SIGNING_KEY"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.signing.secret_id
            version = "1"
          }
        }
      }

      startup_probe {
        http_get {
          path = "/healthz"
          port = 8080
        }
        period_seconds    = 10
        failure_threshold = 6
        timeout_seconds   = 2
      }

      liveness_probe {
        http_get {
          path = "/readyz"
          port = 8080
        }
        period_seconds    = 15
        failure_threshold = 3
        timeout_seconds   = 2
      }
    }
  }

  binary_authorization {
    use_default = true
  }

  depends_on = [
    google_service_account.runtime,
    google_secret_manager_secret.signing,
  ]
}

resource "google_iam_workload_identity_pool" "github" {
  workload_identity_pool_id = "github-pool"
  display_name              = "GitHub"
  description               = "Placeholder pool. Project number is not a real project. Not deployed."
  disabled                  = false
}

resource "google_iam_workload_identity_pool_provider" "github" {
  workload_identity_pool_id          = google_iam_workload_identity_pool.github.workload_identity_pool_id
  workload_identity_pool_provider_id = "github-provider"
  display_name                       = "GitHub OIDC"
  description                        = "Exchanges a GitHub Actions ID token. No JSON key."
  attribute_condition                = "assertion.sub == 'repo:example.invalid/thistle-analytics/insights-api' && assertion.repository == 'example.invalid/thistle-analytics/insights-api'"
  attribute_mapping = {
    "google.subject"       = "assertion.sub"
    "attribute.repository" = "assertion.repository"
  }

  oidc {
    issuer_uri = "https://token.actions.githubusercontent.com"
  }
}
