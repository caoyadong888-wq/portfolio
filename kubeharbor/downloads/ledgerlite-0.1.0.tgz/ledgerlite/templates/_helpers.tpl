{{- define "ledgerlite.name" -}}ledgerlite{{- end -}}

{{- define "ledgerlite.dbSecret" -}}
{{- if eq .Values.postgres.mode "external" -}}
{{- if .Values.externalDatabase.existingSecret -}}
{{- .Values.externalDatabase.existingSecret -}}
{{- else if .Values.existingSecret -}}
{{- .Values.existingSecret -}}
{{- else -}}
ledgerlite-db
{{- end -}}
{{- else -}}
{{- if .Values.existingSecret -}}
{{- .Values.existingSecret -}}
{{- else -}}
ledgerlite-db
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "ledgerlite.requireSecret" -}}
{{- if not .Values.externalSecrets.enabled -}}
{{- if and (not .Values.existingSecret) (not .Values.externalDatabase.existingSecret) -}}
{{- fail "existingSecret is required unless externalSecrets.enabled is true. Set existingSecret to the name of a Secret that contains DATABASE_URL." -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "ledgerlite.image" -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}
{{- end -}}

{{- define "ledgerlite.postgresImage" -}}
{{- printf "%s:%s" .Values.postgres.image.repository .Values.postgres.image.tag -}}
{{- end -}}

{{- define "ledgerlite.host" -}}
{{- if .Values.ingress.host -}}
{{- .Values.ingress.host -}}
{{- else -}}
{{- printf "ledgerlite.%s.example.com" .Values.environment -}}
{{- end -}}
{{- end -}}

{{- define "ledgerlite.tlsSecret" -}}
{{- if .Values.ingress.tlsSecretName -}}
{{- .Values.ingress.tlsSecretName -}}
{{- else -}}
{{- printf "ledgerlite-%s-tls" .Values.environment -}}
{{- end -}}
{{- end -}}

{{- define "ledgerlite.selectorLabels" -}}
app.kubernetes.io/name: ledgerlite
app.kubernetes.io/instance: ledgerlite
app.kubernetes.io/component: {{ . }}
{{- end -}}

{{- define "ledgerlite.metaLabels" -}}
app.kubernetes.io/name: ledgerlite
app.kubernetes.io/instance: ledgerlite
app.kubernetes.io/component: {{ .component }}
app.kubernetes.io/part-of: ledgerlite
{{- end -}}

{{- define "ledgerlite.apiPodSecurityContext" -}}
runAsNonRoot: true
runAsUser: 10001
runAsGroup: 10001
fsGroup: 10001
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "ledgerlite.apiContainerSecurityContext" -}}
allowPrivilegeEscalation: false
privileged: false
readOnlyRootFilesystem: true
runAsNonRoot: true
runAsUser: 10001
runAsGroup: 10001
capabilities:
  drop:
    - ALL
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "ledgerlite.postgresPodSecurityContext" -}}
runAsNonRoot: true
runAsUser: 70
runAsGroup: 70
fsGroup: 70
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "ledgerlite.postgresContainerSecurityContext" -}}
allowPrivilegeEscalation: false
privileged: false
readOnlyRootFilesystem: true
runAsNonRoot: true
runAsUser: 70
runAsGroup: 70
capabilities:
  drop:
    - ALL
seccompProfile:
  type: RuntimeDefault
{{- end -}}
